import Distribution.Simple
import Kairos.Lib 
main = defaultMain
